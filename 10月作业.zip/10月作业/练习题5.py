
import numpy as np
from matplotlib import pyplot as plt



# 第一题

# A = np.array([[7, 2], [3, 4], [5, 3]])
# U, D, V = np.linalg.svd(A)
# print(U)


# 第二题

from PIL import Image

# plt.style.use('classic')
# img = Image.open('d:/123.jpg')
# # img = Image.open('d:/00.jpg')
#
# imggray = img.convert('LA')
# imgmat = np.array(list(imggray.getdata(band=0)), float)
# imgmat.shape = (imggray.size[1], imggray.size[0])
#
# plt.figure(figsize=(9, 6))
# plt.imshow(imgmat, cmap='Accent')       # 改变图片底色
# plt.show()


# A = np.array([[7, 2], [3, 4], [5, 3]])
# U, D, V = np.linalg.svd(A)
# print('U:\n', U)

# img = Image.open('d:/123.jpg')
img = Image.open('d:/123.jpg')
imggray = img.convert('LA')
imgmat = np.array(list(imggray.getdata(band=0)), float)
print(img)      # 输出图片的像素值
# newimg = imgmat.reshape(412,621)

newimg = imgmat.reshape(284, 284)

U,D,V = np.linalg.svd(newimg)
for i in [15, 200]:
    reconstimg=np.matrix(U[:,:i])*np.diag(D[:i])*np.matrix(V[:i,:])
    print(U)
    plt.imshow(reconstimg, cmap='gray')
    title = 'n = %s'% i
    plt.title(title)
    plt.show()

# 第三题




























