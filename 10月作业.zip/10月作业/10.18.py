import numpy as np
from matplotlib import pyplot as plt

# a=np.array([[1,2],[6,4],[3,2]])
# print(a)
# print('\n')
#
# a=np.linalg.norm(a)
# print(a)
# print('\n')

# a=np.array([[7,2],[3,4],[5,3]])
# u,d,v=np.linalg.svd(a)
# print(u)
#
# np.linalg.eig(a.dot(a.T))[1]
# print(a.T)

# from PIL import Image
# plt.style.use('classic')
# img=Image.open('d:/123.jpg')
# imggray=img.convert('LA')
# imgmat=np.array(list(imggray.getdata(band=0)),float)
# imgmat.shape=(imggray.size[1],imggray.size[0])
#
# plt.figure(figsize=(9,6))
# plt.imshow(imgmat,cmap='gray')    #改变突变底色，但必须是专有单词
# plt.show()
#


# img=Image.open('d:/123.jpg')
# imggray=img.convert('LA')
# imgmat=np.array(list(imggray.getdata(band=0)),float)
# newimg = imgmat.reshape(284, 284)
#
# U,D,V = np.linalg.svd(newimg)
# for i in [15, 200]:
#     reconstimg=np.matrix(U[:,:i])*np.diag(D[:i])*np.matrix(V[:i,:])
#     print(U)
#     plt.imshow(reconstimg, cmap='gray')
#     title = 'n = %s'% i
#     plt.title(title)
#     plt.show()


#————————习题一
#1给定A=【7 2】
#     【3 4】，svd方法从A计算U、V、和D
#    【5 3】
# import numpy as np
# A = np.mat("7 2;3 4;5 3")
# print(A,'\n')
# U,Sigma,V = np.linalg.svd(A,full_matrices=False)
# print(U,'\n')
# print(V,'\n')
# print(Sigma,'\n')
# #验证
# # B = (U * np.diag(V) * Sigma)
# # print(B)
# print(np.matrix(U)*np.diag(Sigma)*np.matrix(V))

#2给定图像，采用SVD重建，sv个数分别为5，10，20，30，显示重建图像
from matplotlib import pyplot as plt
import numpy as np
from PIL import Image
plt.style.use('classic')
img = Image.open('d:/123.jpg')
imggray = img.convert('LA')
#转为numpy数组
imgmat = np.array(list(imggray.getdata(band=0)),float)
print(img)
#转为矩阵
newimg = imgmat.reshape(412,621)
U,D,V = np.linalg.svd(newimg)
for i in [200,350]:
    reconstimg = np.matrix(U[:,:i]) * np.diag(D[:i]) * np.matrix(V[:i,:])
    plt.imshow(reconstimg,cmap='gray')
    title = "n = %s"%i
    plt.title(title)
    plt.show()