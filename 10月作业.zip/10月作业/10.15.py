#——————————缩进不一样，会导致运行错误————————
# if True:
#      print('True')
# else:
#      print('False')

# if True:
#     print ("Answer")
#     print ("True")
# else:
#     print ("Answer")
#   print ("False")  #缩进不一样，会导致运行错误

# a = 2
# b = 4
# print(a + b)
# print(a * b)
# print(b / a)
# print(a - b)
# print(a % b)
# print(a ** b)

# a = [1, 2, 3, 4, 5, 6]
# b = a[5]
# print(b)
# a[1] = 12
# print(a)
# c = len(a)
# print(c)
# del a[3]
# print(a)
# f = a + [1, 2, 2, 11, 12, 13]
# print(f)

# a.append(99)
# print(a)
# for i in a:
#     print(i)
#     if i == 6:
#         a.append(100)
#        print(a)
#     else:
#        a.remove(i)
#        print(a)

# dict = {}
# dict['one'] = '123'
# dict[2] = '456'
# tin = {'name': 'runoob', 'code': 'oo', 'dd': 'apple'}
# print(dict['one'])
# print(dict)
# dict[1] = 789
# print(dict)
# print(tin)
# print(tin.get('na', 'ONG'))

# a = '123'
# b = float(a)
# print(type(a))
# print(type(b))

# a = 1
# while a<10:
# print(a)
# a +=2

#————————for循环————————
# languages =["c","c++","java","python"]
# for x in languages :
#           print(x)

#——————————break————————
# sites =["c","c++","java","python"]
# for site in sites :
#      if site =="java":
#           print("菜鸟教程!")
#           break
#      print("循环数据"+site)
# else:
#     print("没有循环数据！")
# print("完成循环！")

#————————continue语句————————

# a=3
# print(str(a*3)+str(a)*3)

#——————使用while计算1到100的总和————————
# def sum():
#     sum=0
#     x=1
#     while x < 101:
#         sum = sum + x
#         x+=1
#     return sum
# print(sum())

#——————使用for计算1到100的总和————————
def sum():
    sum = 0
    for n in range(1,101):
        sum =sum + n
    return sum
print(sum())

# year = int(input("输入一个年份："))
# if(year % 4)==0:
#     if(year % 100)==0:
#         if(year % 400)==0:
#         print("{0}是闰年".format(year))
# else:
#      print("{0}不是闰年".format(year))
#     else:
#          print("{0}是闰年".format(year))
#         else:
#             print("{0}不是闰年".format(year))