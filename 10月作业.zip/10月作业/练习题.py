import numpy as np

#—————创建一个长度为10的一维全为0的ndarray对象，然后让第五个元素等于1
# a=np.array([0,0,0,0,0,0,0,0,0,0])
# a[4]=1
# print(a)

# a=np.array([0,0,0,0,0,0,0,0,0,0])#索引
# a[5]=1
# b=a[0:10:1]     #从索引 1 开始到索引 100 停止，间隔为2
# print(b)

#—————创建一个5*3随机矩阵和一个3*2随机矩阵，求矩阵的积
# a=np.empty([5,3],dtype=int)
# print('第一个数组')
# print(a)
# print('\n')
# b=np.empty([3,2],dtype=int)
# print('第二个数组')
# print(b)
# print('\n')

# print('两个数组相乘')
# print(np.dot(a,b))
# print('\n')

#————————实现冒泡排序法
# list=[]
# print('你想排列几个数字？')
# try:
#     num=int(input())
#     for i in range(num):
#         a=int(input('请输入第'+str((i+1))+'个整数：'))
#         list.append(a)
# except ValueError:
#     print('输入有误！')
# print(sorted(list,reverse=True))

#———————找到数组[1,2,0,0,4,0]中0 的位置索引
# a=np.array([1,2,0,0,4,0])#索引
# print('原数组为\n',a)
# i1=0
# for i in a:
#     i1 +=1
#     if i ==0:
#         print(i1-1)

#————创建一个10*10的随机数组，并找到最大值和最小值
a=np.empty([5,1],dtype=int)
print('原数组')
print(a)
print('\n')
print('最大值为：')
print(np.max(a))
print('\n')
print('最小值为：')
print(np.min(a))
print('\n')

#——————求方程


