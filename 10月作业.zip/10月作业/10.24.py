import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


pd.test
s=pd.Series(['wang','man','24','789'])
print(s)

dates=pd.date_range('20120101',periods=6)
print(dates)

#——————————绘图
# ts = pd.Series(np.random.randn(1000),index=pd.date_range('1/1/2000',periods=1000))
# ts = ts.cumsum()
# ts.plot()
# plt.show()
#
# df=pd.DataFrame(np.random.randn(1000,4),index=ts.index,columns=['A','B','C','D'])
# df=df.cumsum()
# plt.figure()
# plt.show()
#
# df.plot()
# plt.show()
# plt.legend(loc='best')

#———————————————数据输入\输出
# df.to_csv('foo.csv')
# print(pd.read_csv('foo.csv'))
#
# df.to_excel('foo1.xlsx',sheet_name='Shent1')
# print(pd.read_excel('foo1.xlsx','Shent1',index_col=Name,na_values=['NA']))

fig=plt.figure()
ax=fig.add_subplot(111)       #前两个参数确定面板划分，如：22讲整个面板划分为2*2的方格，第三个参数确定位置
ax=fig.add_subplot(222)
ax=fig.add_subplot(224)
ax.set(xlim=[0.5,4.5],ylim=[-2,8],title='An Example Axes',ylabel='Y',xlabel='X')
plt.show()

# x=np.linspace(0,np.pi)
# y_sin=np.sin(x)
# y_cos=np.cos(x)
# ax1.plot(x,y_sin)
