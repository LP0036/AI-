a=eval(input('请输入数字：'))
c=a+10
#print(c)
for i in range(10):
    b=c+1
print(b)