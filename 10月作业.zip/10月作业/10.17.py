import numpy as np
from matplotlib import pyplot as plt
# x=np.array([1,2,3,4])
# print(x)

# A=np.array([[1,2],[3,4],[5,6]])
# print(A)    #输出三行两列
#
# A_T=A.T
# print(A_T)   #输出两行三列

# a=np.array([[3,0,2],[2,0,2],[0,1,1]])
# print(a)
#
# a_inv=np.linalg.inv(a)
# print(a_inv)
#
# a_bis=a_inv.dot(a)
# print(a_bis)

# a=np.array([[2,-1],[1,1]])
# print(a)
#
# b=np.linalg.inv(a)
# print(b)
#
# c=np.array([[0],[3]])
# x=b.dot(c)
# print(x)

# x = np.arange(-10,10)
# y = 2*x
# y1 = -x + 3
#
# plt.figure()
# plt.plot(x,y)
# plt.plot(x,y1)
# plt.xlim(0,3)
# plt.ylim(0,3)
#
# plt.axvline(x=0,color='red')
# plt.axhline(y=0,color='grey')
# plt.show()
# plt.close()

# a=np.array([[5,1],[3,3]])
# print(a)
#
# b=np.linalg.eig(a)
# print(b)

t=np.linspace(0,2*np.pi,100)
x=np.cos(t)
y=np.sin(t)
plt.figure()
plt.plot(x,y)
plt.xlim(-1.5,1.5)
plt.ylim(-1.25,1)
plt.show()

# a=np.random.randn(200,500)
# b=np.random.randn(500,500)
# def fun(l):
#     return np.dot(a,np.dot(b,1*np.eye(500)))
# res1=a+a
# res2=np.dot(a,a.T)
# res3=np.dot(a.T,a)
# res4=np.dot(a,b)
# l=int(input("lambda"))
# res5=fun(l)