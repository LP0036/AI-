# from numpy import *
# print(eye(4))

import numpy as np

# a= np.array([[1,2],[3,4]])
# print(a)

# a=np.array([[1,2,3],[4,5,6]])
# print(a.shape)

# x=np.empty([3,2],dtype=int)
# print(x)

# x=np.ones(10)   #10列
# print(x)

# x=np.ones([5,2],dtype=int)    #5行2列
# print(x)

#——————————numpy从已有数组中创建数组
# x=[1,2,3]    #将列表转换为nbarray
# a=np.asarray(x)
# print(x)

# x=(1,2,3)    #将元组转换为nbarray
# a=np.asarray(x)
# print(a)

# x=[1,2,3]    #设置了dtype参数
# a=np.asarray(x,dtype=float)
# print(a)

#————————numpy从数值范围创建数组
# x= np.arange(0,20,3)
# print(x)

# a=np.arange(100)    #索引
# b=a[1:100:2]     #从索引 1 开始到索引 100 停止，间隔为2
# print(b)

# a=np.array([[1,2,3,4],[3,4,5,6],[5,6,7,8],[1,4,7,9]])
# print(a)
# print('从数组索引 a[1:]出开始切割')
# print(a[1:])    #从列表一二个元素（即:[3,4,5.]）开始切割，直到最后一个

#——————————numpy广播(broadcast)
# a=np.array([[]
#
#             ])

#————————numpy数组操作
# a=np.arange(20).reshape(5,4)
# print('原数组')
# print(a)
# print('\n')
#
# print('展开的数组：')    #——————默认按行
# print(a.flatten())
# print('\n')
#
# print('以F风格顺序展开的数组：')   #'F'————按列
# print(a.flatten(order = 'F'))
#
# print('以C风格顺序展开的数组：')
# print(a.flatten(order = 'C'))     #'C'————按行     'A'————按与按顺序
#
# print('以K风格顺序展开的数组：')
# print(a.flatten(order = 'K'))     #'K'————按元素在内存中出现的顺序

#——————链接数组
# a=np.array([[1,2],[3,4]])
# print('第一个数组')
# print(a)
# print('\n')

# b=np.array([[5,6],[7,8]])
# print('第二个数组')
# print(b)
# print('\n')
#
# print('沿轴0链接讲个数组')
# print(np.concatenate(a,b))
# print('\n')
#
# print('沿轴1链接讲个数组')
# print(np.concatenate((a,b),axis=1))

#————————舍入函数（decimals：）
# a=np.array([1.0,5.55,123,0.567,25.532])
# print('原数组')
# print(a)
# print('\n')
# print('舍入后')
# print(np.around(a))
# print(np.around(a,decimals=1))   #decimals：舍入的小数位数。默认值为0.如果为负，
# print(np.around(a,decimals=-1))  #整数讲四舍五入到小数点左侧的位置

#————————算数函数（加减乘除）
# a=np.arange(9,dtype=np.float_).reshape(3,3)
# print('第一个数组')
# print(a)
# print('\n')
# print('第二个数组')
# b=np.array([10,10,10])
# print(b)
# print('\n')
# print('两个数组相加')
# print(np.add(a,b))
# print('\n')
# print('两个数组相减')
# print(np.subtract(a,b))
# print('\n')
# print('两个数组相乘')
# print(np.multiply(a,b))
# print('\n')
# print('两个数组相除')
# print(np.divide(a,b))
# print('\n')

#——————统计函数
# a=np.array([[30,65,70],[80,95,10],[50,90,60]])
# print('我们的数组是：')
# print(a)
# print('\n')
# print('调用median()函数')
# print(np.median(a))
# print('\n')
# print('沿轴0调用median()函数')
# print(np.median(a,axis=0))
# print('\n')
# print('沿轴1调用median()函数')
# print(np.median(a,axis=1))

# a = np.arange(15).reshape(5, 3)
# print('第一个数组')
# print(a)
# print('\n')
# print('第二个数组')
# a = np.arange(6).reshape(3, 2)
# print(b)
# print('\n')
# print('两个数组相乘')
# print(np.multiply(a,b))
# print('\n')

