#——————————缩进不一样，会导致运行错误————————
# if True:
#      print('True')
# else:
#      print('False')

# if True:
#     print ("Answer")
#     print ("True")
# else:
#     print ("Answer")
#   print ("False")  #缩进不一样，会导致运行错误

# a = 2
# b = 4
# print(a + b)
# print(a * b)
# print(b / a)
# print(a - b)
# print(a % b)
# print(a ** b)

# a = [1, 2, 3, 4, 5, 6]
# b = a[5]
# print(b)
# a[1] = 12
# print(a)
# c = len(a)
# print(c)
# del a[3]
# print(a)
# f = a + [1, 2, 2, 11, 12, 13]
# print(f)

# a.append(99)
# print(a)
# for i in a:
#     print(i)
#     if i == 6:
#         a.append(100)
#        print(a)
#     else:
#        a.remove(i)
#        print(a)

# dict = {}
# dict['one'] = '123'
# dict[2] = '456'
# tin = {'name': 'runoob', 'code': 'oo', 'dd': 'apple'}
# print(dict['one'])
# print(dict)
# dict[1] = 789
# print(dict)
# print(tin)
# print(tin.get('na', 'ONG'))

# a = '123'
# b = float(a)
# print(type(a))
# print(type(b))

# a = 1
# while a<10:
# print(a)
# a +=2

#————————for循环————————
# languages =["c","c++","java","python"]
# for x in languages :
#           print(x)

#——————————break————————
# sites =["c","c++","java","python"]
# for site in sites :
#      if site =="java":
#           print("菜鸟教程!")
#           break
#      print("循环数据"+site)
# else:
#     print("没有循环数据！")
# print("完成循环！")

#————————continue语句————————

# a=3
# print(str(a*3)+str(a)*3)

#——————使用while计算1到100的总和————————
# def sum():
#     sum=0
#     x=1
#     while x < 101:
#         sum = sum + x
#         x+=1
#     return sum
# print(sum())

#——————使用for计算1到100的总和————————
# def sum():
#     sum = 0
#     for n in range(1,101):
#         sum =sum + n
#     return sum
# print(sum())

# year = int(input("输入一个年份："))
# if(year % 4)==0:
#     if(year % 100)==0:
#         if(year % 400)==0:
#         print("{0}是闰年".format(year))
# else:
#      print("{0}不是闰年".format(year))
#     else:
#          print("{0}是闰年".format(year))
#         else:
#             print("{0}不是闰年".format(year))

# def holle():
#     print("hello world!")

#————————面积计算————————
# def area(width,height):
#     return width * height
# def print_welcome(name):
#     print("welcome",name)
# print_welcome("Runoob")
# w = 4
# h = 5
# print("width =",w,"height =",h,"area =",area(w,h))


# def sum(arg1,arg2):
#     total = arg1 + arg2
#     print("函数内：",total)
#     return total
# total = sum(10,20)
# print ("函数外：

#————————输入输出
# str=input("请输入：")
# print("你输入的内容是：",srt)

#————————打开一个文件写
# fow ="123,456,789"
# f = open("mima.txt","w")
# f.write("密码：{}\n".format(fow))
# f.close()

# f = open("mima.txt","w")
# f.write("python是一门很好的语言\n")
# f.close()

#————————打开一个文件读
# f = open("mima.txt","r")
# # str = f.read()
# # print(str)
# # f.close()
#————————先转换
# f = open("mima.txt","w")
# value=("www.runoob.com",14)
# s=str(value)
# f.write(s)
# f.close()

#————————Class类的对象
# class MyClass:
#     i = 12345
#     def f(self):
#         return 'hello wurld'
# x = MyClass()
# print("MyClass 类的属性i为：",x.i)
# print("MyClass 类的方法f输出为：",x.f())

#———————第一题


#———————第二题
# def area(radiue):
#     return 3.14*radiue*radiue
# def print_welcome(name):
#     print("welcome",name)
# print_welcome("Runoob")
# r = 4
# print("radiue =",r,"area =",area(r))

# from numpy import *
# eye(4)
# array([[1.,0.,0.,0.],
#       [0.,1.,0.,0.],
#       [0.,0.,1.,0.],
#       [0.,0.,0.,1.]])

