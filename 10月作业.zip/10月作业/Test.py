import numpy as np
"""
str="runnoob";
print(str);
print(str[0:-1]);
print(str[0]);
print(str[2:5]);
print(str[2:]);
print(str+"你好");
print("hello\nrunnoob");
print(r"hello\nrunnoob");
"""

"""
a="hello"
b="python"
print("a+b 输出结果：",a+b)
print("a*2 输出结果：",a*2)
print("a[1] 输出结果：",a[1])
if("h" in a):
    print("h在变量a中")
else:
    print("h不在a中")
if ("m" in a):
    print("m在变量a中")
else:
    print("m不在a中")
    """
"""
print("我叫%s 今年%d 岁!"%("小明",10))
"""

"""
dict={}
dict["one"]="1-菜鸟教程"
dict[2]="2-菜鸟工具"

tinydict={'name':'runoob','code':1,'site':'www.runoob.com'}

print(dict['one'])
print(dict[2])
print(tinydict)
print(tinydict.keys())# 输出所有键
print(tinydict.values())# 输出所有值
"""

"""
a,b=0,1
c=1.344
print(float(a))
print(float(b))
print(int(c))
while b<10:
    print(b,end=",")
    a,b=b,a+b
print(float(a))
"""

"""
a=1
while a<7:
    if(a%2==0):
        print(a,"is even")
    else:
        print(a,"is odd")
    a+=1
"""

"""
age=int(input("请输入你的年龄："))
if age<=0:
    print("这不可能！")
elif age>=100:
    print("这也太长寿了!")
elif 0<age<100:
    print("今年你",+age)
"""

"""
sites=["Baidu","Google","Runoob","Taobao"]
for site in sites:
    if site=="Runoob":
        print("菜鸟教程！")
        break;
    print("循环数据"+site)
else:
    print("没有循环数据！")
print("完成循环！")
"""

"""
for i in range(5):
    print(i,end=" ")
print("\n")
for i in range(5,9):
    print(i,end=" ")
print("\n")
for i in range(0,100,10):
    print(i,end=" ")
    """
"""
for letter in"Runoob":
    if letter=="b":
        break
    print("当前字母为：",letter)
    print("\n")
"""

"""
for letter in"Runoob":
    if letter=="o":
        break
    print("当前字母为：",letter,end=" ")
print("\n")


for letter in "Runoob":
    if letter =="o":
        continue
    print ("当前字母为：",letter,end=" " )
"""
"""
 for n in range(2,10):
    for x in range(2，n):
        if n %x==0:
            print(n,"等于",x,"*",n//x)
            break
        else:
        print(n,"是质数")

a=3
print(str(a*3)+str(a)*3)

string="this is my string"
x=0
for g in string:
    x=x+1
    print(x,end=" ")
print("\n")
print(len(string))

a=0
sum=0
while a<101:
    sum=sum+a
    a=a+1
    print(sum,end=" ")
    if a%10==0:
        print("\n")

age=int(input("请输入年份："))
if age%4==0:
    print(age,"是闰年")
else:
    print("不是闰年")





#第七题
a=1
while a<=5:
    print(a*"*")
    a = a + 1
a = a-1
while (a>=0):
    print(a*"*")
    a = a - 1


#第八题
a=int(input("请输入一个数："))
b=int(input("请输入一个数："))

if a>b:
    while b<=a:
        print(b)
        b= b + 1
else:
    max = a
    a=b
    b=max
    while b<=a:
        print(b)
        b= b + 1

#第九题
sum=0
for a in range(4):
    for b in range(4):
       for c in range(4):
           sum = sum + 1
           print(a,b,c,sum)
           print("\n")
"""
#第十题！！！！！！
#一个整数，它加上100后是一个完全平方数，再加上168又是一个完全平方数，请问该数是多少？


"""
#第十一题
a=int(200/17)
print(a*17)
"""

"""
#第十二题！！！！！
#输入一个正整数n，对其进行因式分解，并输出。例如：输入18，输出18=2*3*3.
def primeNum(num):
    if num==1:
        return []
    else:
        for i in range(2, num+1):#range返回2到num+1的一系列连续添加的整数。
            n,d=divmod(num,i)
            if d==0:
                return [i]+prinmenum(n)
        print(n,"=","*".join(str,print(n)))
   """



"""
#第十三题
a=100
sum=0
for i in range(1,10):
    sum+=a
    a = a / 2
    print(sum)
"""



"""
#第十四题！！！！！！！！
#函数用于判断某一个数是不是素数
def test(num):
    list = [] #定义列表，用于存储计算
    i = num -1#去除本身
    while i > 1:#去除1
        if num%i == 0: #判断是否有余数
            list.append(i)#将所以有的能整除它数加入列表
        i -= 1
    if len(list) == 0:#如果列表为空，就是表示除了1个它本身能整除
        print(num,end=" ")

#此函数用于判断计算出需要判断的所有数字100～200
def test2(star_num,and_num):
    j = star_num
    while j < and_num:
        test(j)
        j += 1

test2(100,200)
print("")
"""

"""
#第十五题
d={"a":1,"b":2,"c":3}
print(d.keys())# 输出所有键
print(d.values())# 输出所有值
"""

"""
def hello ( name):
    print("hello ",name,"!!!")

name=input("请输入名字：")
hello(name)
"""

"""
#计算面积函数
def area(width,height):
    return(width*height)
def hello ( name):
    print("hello ",name,"!!!")
hello("hege")
w=int(input("请输入数值："))
h=int(input("请输入数值："))
print("width=",w,"height=",h,"area=",area(w,h))


def sum(arg1,arg2):
    #返回两个参数的和
    total=arg1+arg2
    return total
t=sum(4,8)
print("4+8=",t)


#coding=utf-8
f=open("foo.txt","w")
f.write("python 是一个很好的语言。\n是的。")
f.write("\n------------------------hege")

f.close()


f=open("foo.txt","r")
str=f.read()
print(str)
f.close()


f=open("foo.txt","r")
value=("www.runoob.com",14)
t=str(value)
print(t)
f.close()


class MyClass:
    i=12345
    def f(self):
        return "hello world"
x=MyClass()
print("MyClass 类的属性 i为：",x.i)
print("MyClass 类的属性 f输出为：",x.f())



#第一题
list=[]
def add(x,y,z,k):
    list.append({"name":x,"tel":y,"email":z,"wUnit":k})
    print("添加成功！")
    return
def select():
    for i in list:
        print(i)
    return
def delete(x):
    del list[x]
    print("删除成功！" )
    return
while True:
        print("1.增加姓名")
        print("2.删除姓名")
        print("3.查询用户")
        print("0.退出")
        try:
            a = int(input("请输入要执行的项目："))
            if (a==0):
                break
            elif(a==1):
                name=input("请输入姓名：")
                tel=input("手机号码：")
                email=input("email:")
                wUnit=("工作单位：")
                add(name,tel,email,wUnit)
            elif (a==2):
                i=int(input("请输入要删除的姓名："))
                delete(i)
                break
            else:
                select()
        except:
            print("请输入信息！")
"""



"""
#第二题
#计算圆的周长面积，球的表面积体积。
class yunsuan:
    def zhouchang(self,r):
        s=2*3.14*r
        return s
    def area(self,r):
        s=3.14*r*r
        return s
    def surface(self,r):#球的表面积
        s=4*3.14*r*r
        return s
    def volume(self,r):#球的体积
        s=(4/3)*3.14*r*r*r
        return s
a=yunsuan()
r=int(input("请输入半径："))
print("圆的周长为：",a.zhouchang(r))
print("圆的面积为：",a.area(r))
print("球的表面积为：",a.surface(r))
print("球的体积为：",a.volume(r))
"""

"""
#第三题
print("请选择输入;")
print("1：华氏度")
print("2:摄氏度")
a=float(input("你的选择："))
if a==1:
    c=5/9*(a-32)
    print("摄氏度为：",c)
else:
    f=(9/5*a)+32
    print("华氏度为：",f)
"""

"""
#第四题
import random
f=open("foo1.txt","w")
for i in range(1, 1000):
    f.write(str(random.randint(1,100))+"\n")
f.close()
"""

"""
#第五题
i=0
for line in open("foo1.txt"):
    print("第",i,"行",line)
    i=i+1
"""


"""
#第六题



"""

"""
from numpy import *
print(eye(4))


"""
import numpy as np
"""
a=np.array([[1,2,3,4],[4,5,6,7]])
print(a.shape)
print(a)
x=np.empty([3,2],dtype=int)#empty随机给出一些整形的数组
print(x)
print(np.ones(5))#五个值为1的一维数组
print(np.ones(3))
print(np.zeros(3))#三个值为0的一维数组


#元组转换为ndarray
x=(1,2,3)
a=np.asarray(x)
print(a)

#列表转换为ndarray
x=[1,2,3]
a=np.asarray(x,dtype=float)#转换为float类型
print(a)
"""
"""
#产生10到20每隔2个的数组
x=np.arange(10,20,2)
print(x)

#索引
a=np.arange(10)
#b=a[2:7:2]#从索引2开始到索引7结束，间隔为2
b=a[3:7]#从索引3开始到索引7结束，间隔为1
print(b)
"""
"""
a=np.array([[1,2,3],[3,4,5],[4,5,6]])

print(a)
print("\n")
print(a[1:])#从数组索引a[1:]开始切割
print("\n")
print(a[2:])#从数组索引a[2:]开始切割

print(a[2:,...])#取指定行
print("\n")
print(a[...,2])#取指定列
print(a[...,0])#取指定第0列

a=np.arange(8).reshape(2,4)
print("原数组")
print(a)

print("展开的数组")
print(a.flatten())

print("按F风格展开的数组 F--按列")
print(a.flatten(order="F"))

print("按C风格展开的数组 C--按行")
print(a.flatten(order="C"))

print("按A风格展开的数组 A--原顺序")
print(a.flatten(order="A"))

print("按K风格展开的数组 K--元素在内存中出现顺序")
print(a.flatten(order="K"))


a=np.arange(12).reshape(3,4)
print("原数组：")
print(a)
print("\n")

print("对换数组：")
print(np.transpose(a))

#两个数组的维度相同
a=np.array([[1,2],[3,4],[4,5]])
print("a数组：")
b=np.array([[5,6],[6,7],[7,8]])
print("b数组:")
print("沿0轴连接两个数组：")#0轴就是行
print(np.concatenate((a,b)))#1轴就是列
print("沿1轴连接两个数组：")
print(np.concatenate((a,b),axis=1))


a=np.array([1.0,5.55,123,0.465,23.4656])
print("原数组：")
print(a)
print("舍入后：")
print(np.around(a))
print(np.around(a,decimals=1))
print(np.around(a,decimals=2))
print(np.around(a,decimals=-1))
print(np.floor(a))#向下取整
print(np.ceil(a))#向上取整
"""
"""
a=np.arange(9,dtype=np.float_).reshape(3,3)
print("第一个数组：")
print(a)
print("第e二个数组:")
b=np.array([10,10,10])
print(b)
print("两个数组相加：")
print(np.add(a,b))
print("两个数组相减：")
print(np.subtract(a,b))
print("两个数组相乘：")
print(np.multiply(a,b))
print("两个数组相除：")
print(np.divide(a,b))
"""


"""
#第一题
a=np.zeros(10)
a[4]=1
print(a)

#第二题
#计算两个数组的积
import numpy as np
a=np.empty([5,3],dtype=int)
b=np.empty([3,2],dtype=int)
print(np.dot(a,b))

#第三题
#冒泡排序：两个相邻数进行比较，小的放在前面。
def maopao():
    a=[14,3,25,31,11,6,12,42,11]
    n=len(a)
    for i in range( n):
        for i in range(0,n-i-1):
            if a[i]>a[i+1]:
                j=a[i]
                a[i]=a[i+1]
                a[i+1]=j
            else:
                i=i+1
    for i in range(len(a)):
        print(a[i])
print(maopao())

#第四题
a=[1,2,0,0,4,0]
n=len(a)
for i in range(n):
    if a[i]==0:
        print("0位置的索引：")
        b=a[i:]
        print(b)
    else:
        i=i+1

#第五题
#找数组最大最小值
a = np.empty([10, 10], dtype=int)#创建一个10*10的数组
print(a)
print(a.min())
print(a.max())
"""
"""
#第六题
#解方程
import sympy #引入解方程专业模块sympy
x=sympy.symbols("x")#申明未知数
a=sympy.solve(x+(1/5)*x-240,[x])
print(a)
"""

"""
x=np.array([1,2,3,4])
print(x)


A=np.array([[1,2],[3,4],[5,6]])
print(A)
print("\n")
A_t=A.T
print(A_t)
print("\n")
B=np.array([[2,4],[3,4],[6,6]])
print(B)
C=A+B
print(C)

A=np.array([[3,0,2],[2,0,-2],[0,1,1]])
print(A)
A_inv=np.linalg.inv(A)
print(A_inv)
A_bis=A_inv.dot(A)
print(A_bis)
"""

"""
import matplotlib.pyplot as plt#导入画图包
x=np.arange(-10,10)#产生测试数据
y=2*x
y1=-x+3

plt.figure()#设置画图区域大小和像素
#plt.legend(loc=0)#显示画图位置
plt.plot(x,y)
plt.plot(x,y1)
#plt.axis()#修改坐标轴刻度显示
plt.xlim(0,3)
plt.ylim(0,3)
plt.axvline(x=0,color="grey")
plt.axhline(y=0,color="grey")
plt.show()#显示所画图
plt.close()

V=np.array([[1,1],[1,-3]])
print(V)
lambdas=np.diag([6,2])#矩阵本征分解
print(lambdas)
V_inv=np.linalg.inv(V)
print(V_inv)
print(V.dot(lambdas).dot(V_inv))
print(np.linalg.eig(V))

t=np.linspace(0,2*np.pi,100)
x=np.cos(t)
y=np.sin(t)

plt.figure()
plt.plot(x,y)
plt.xlim(-1.5,1.5)
plt.ylim(-1.5,1.5)
plt.show()


t1=[1,5,1,5]
t2=np.array([1,5,1,5])
plt.plot(t1,"b--",2,"r--")#一起载入t1,t2
#plt.plot(t2)#单独载入t2
plt.show()


x1=[1,5,1,5]
y1=[1,3,4,5]
x2=[2,5,6,9]
y2=[1,5,8,10]
plt.plot(x1,y1,"r-",x2,y2,"g--")
plt.show()


#绘制f(x)=sin(x)和g(x)=cos(x)在x属于[0,20]中的图像
x=np.arange(0,20,0.01)
plt.plot(x,np.sin(x),"r-",x,np.cos(x),"b--")#修改线的颜色和形状
plt.axis([0,20,-3,3])#修改坐标轴刻度显示
plt.grid(True)#显示网格线
plt.xlabel("x zhou")#增加x轴文字
plt.ylabel("y zhou")#增加y轴文字
plt.title("f(x)=sin(x),f(x)=cos(x)")#增加标题
plt.show()
"""

"""
#练习1
import numpy as np
A=np.random.randn(200,500)
B=np.random.randn(500,500)
def fun(l):
    return np.dot(A,np.dot(B,l*np.eye(500)))#dot获取两个元素的乘积

res1=A+A
res2=np.dot(A,A.T)
res3=np.dot(A.T,A)
res4=np.dot(A,B)
l=int(input("lambda:"))
res5=fun(l)
print(res5)
"""
"""
#第二题

import matplotlib.pyplot as plt#导入画图包

A=np.array([[-1,3],[2,-2]])
print(A)
v=np.array([[2],[1]])
print(v)
plt.plot(A,v,"r-")#修改线的颜色和形状
plt.show()
"""
"""
plotVectors([v.flatten()],cols=["#1190FF"])
plt.xlim(-1,4)#限定横轴的范围
plt.ylim(-1,4)#限定纵轴的范围
Av=A.dot(v)
print(Av)
plotVectors([v.flatten(),Av.flatten()],cols=["#1190FF","#FF9A13"])
plt.xlim(-1,4)#限定横轴的范围
plt.ylim(-1,4)#限定纵轴的范围
plt.show()
"""
"""
#第三题
v=np.array([[1],[1]])
"""
"""
#求矩阵的模

A=np.array([[1,2],[6,4],[3,2]])
print(A)
print(np.linalg.norm(A))

import numpy as np
from PIL import Image
from matplotlib import pyplot as plt
plt.style.use("classic")
img=Image.open("test.jpg")
imggray=img.convert("LA")
imgmat=np.array(list(imggray.getdata(band=0)),float)
imgmat.shape=(imggray.size[1],imggray.size[0])

plt.figure(figsize=(9,6))
plt.imshow(imgmat,cmap="gray")
plt.show()
"""
import numpy as np
#from PIL import Image
from matplotlib import pyplot as plt
"""
import numpy as np
#from PIL import Image
from matplotlib import pyplot as plt

t=np.linspace(0,2*np.pi,100)#linspace用来实现相同间隔的采样
x=np.cos(t)
y=np.sin(t)

plt.figure()
plt.plot(x,y)
plt.xlim(-1.5,1.5)
plt.ylim(-1.5,1.5)
plt.show()


#上机1
#用svd方法从A计算U,V和D
A=np.array([[7,2],[3,4],[5,3]])
U,D,V=np.linalg.svd(A)
print(U)
print(np.linalg.eig(A.dot(A.T))[1])




#上机2
#给定图像，采用svd重建，sv个数分别为5，10，20，30，显示重建图像(svd--奇异值分解)

from scipy.misc import face
from scipy.linalg import svd,eig,diagsvd,lu
import  skimage

imgrgb=face()
img=skimage.color.rgb2gray(imgrgb)
print(img.shape)
U,D,V=svd(img)
print(U.shape,D.shape,V.shape)

for i in [5,10,15,20,30,50]:
    reconstruct =np.matrix(U[:,:i])*np.diag(D[:i])*np.matrix(V[:i,:])
    plt.imshow(reconstruct,cmap="gray")
    title="n=%s"%i
    plt.title(title)
    plt.show()
"""



"""
import numpy as np
from PIL import Image
from matplotlib import pyplot as plt
plt.style.use("classic")
img=Image.open("test.jpg")
imggray=img.convert("LA")
imgmat=np.array(list(imggray.getdata(band=0)),float)
imgmat.shape=(imggray.size[1],imggray.size[0])

plt.figure(figsize=(9,6))
plt.imshow(imgmat,cmap="gray")
plt.show()



A=np.array([[0,1],[1,1],[2,1],[3,1],[3,1],[4,1]])
b=np.array([[2],[4],[0],[2],[5],[3]])
A_plus=np.linalg.pinv(A)
print(A_plus)



coefs=A_plus.dot(b)
coefs


t=np.linspace(0,2*np.pi,100)
x=np.cos(t)
y=np.sin(t)

plt.figure()
plt.plot(x,y)
plt.xlim(-1.5,1.5)
plt.ylim(-1.5,1.5)
plt.show()


#上机1
#用svd方法从A计算U,V和D
A=np.array([[7,2],[3,4],[5,3]])
U,D,V=np.linalg.svd(A)
print(U)
print(np.linalg.eig(A.dot(A.T))[1])

"""


#上机2
#给定图像，采用svd重建，sv个数分别为5，10，20，30，显示重建图像(svd--奇异值分解)

from scipy.misc import face
from scipy.linalg import svd,eig,diagsvd,lu
import  skimage

imgrgb=face()
img=skimage.color.rgb2gray(imgrgb)
print(img.shape)
U,D,V=svd(img)
print(U.shape,D.shape,V.shape)

for i in [5,10,15,20,30,50]:
    reconstruct =np.matrix(U[:,:i])*np.diag(D[:i])*np.matrix(V[:i,:])
    plt.imshow(reconstruct,cmap="gray")
    title="n=%s"%i
    plt.title(title)
    plt.show()

"""
np.random.seed(123)
x=5*np.random.rand(100)
y=2*x+1+np.random.randn(100)

x=x.reshape(100,1)
y=y.reshape(100,1)

A=np.hstack((x,np.ones(np.shape(x))))
A[:10]

A_plus=np.linalg.pinv(A)
coefs=A_plus.dot(y)
coefs

x_line=np.linspace(0,5,1000)
y_line=coefs[0]*x_line+coefs[1]

plt.plot(x,y,'*')
plt.plot(x_line,y_line)
plt.show()





from PIL import Image
from matplotlib import pyplot as lit
plt.style.use("classic")
img=Image.open("test.jpg")
#print(img)
imggray=img.convert("LA")
imgmat=np.array(list(imggray.getdata(band=0)),float)
newing=imgmat.reshape(272,411)
U,D,V=np.linalg.svd(newing)

for i in [5,10,15,20,30,50]:
    reconstruct =np.matrix(U[:,:i])*np.diag(D[:i])*np.matrix(V[:i,:])
    plt.imshow(reconstruct,cmap="gray")
    title="n=%s"%i
    plt.title(title)
    plt.show()



"""

