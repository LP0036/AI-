import numpy as np
from matplotlib import pyplot as plt

# x = np.array([1, 2, 3, 4])
# print(x)
#
# print('***************************')
# A = np.array([[1, 2], [3, 4], [5, 6]])
# print(A)
#
# print('***************************')
# B = np.array([[2, 5], [7, 4], [4, 3]])
# print(B)
#
# print('***************************')
# # 两矩阵相加需要两矩阵的维数相同，否则不能相加
# C = A + B
# print('相加后：', C)
#
# print('***************************')
# 相乘，前一个的列数要与后一个的行数一致才能运算
# A = np.array([[1, 2], [3, 4], [5, 6]])
# B = np.array([2, 3])
#
# print('矩阵A:\n', A)
# print('矩阵B：\n', B)
#
# D = A * B
# print('相乘后：\n', D)

# print('***************************')
# a = np.array([[3, 0, 2], [2, 0, -2], [0, 1, 1]])
# print('a:\n', a)
#
# a_inv = np.linalg.inv(a)            # 逆矩阵
# print('a_inv:\n', a_inv)
#
# a_bis = a_inv.dot(a)                # 矩阵a与逆矩阵的点积后得到单位矩阵 a_bis （dot 函数的作用为两个数组的点积，即元素对应相乘）
# print('a_bis:\n', a_bis)



# print('***************************')
x = np.arange(-10, 10)
y = 2 * x
y1 = -x + 3

plt.figure()
plt.plot(x, y)
plt.plot(x, y1)
plt.xlim(0, 3)
plt.ylim(0, 3)

plt.axvline(x=0, color='grey')
plt.axhline(y=0, color='grey')
plt.show()
plt.close()

# print('***************************')
# v = np.array([[1, 1], [1, -3]])           # 典型矩阵
# print('v:\n', v)
#
# v_inv = np.linalg.inv(v)                  # 逆矩阵
# print('v_inv:\n', v_inv)
#
# lambdas = np.diag([6, 2, 1, 2])           # 对角矩阵
# print('lambdas:\n', lambdas)
#
# lambdas = np.diag([6, 2])                 # 对角矩阵
# print('lambdas:\n', lambdas)
#
#
# print('\n', v.dot(lambdas).dot(v_inv))
#
# print('***************************')

# t = np.linspace(0, 2 * np.pi, 100)
# x = np.cos(t)
# y = np.sin(t)
#
# plt.figure()
# plt.plot(x, y)
# plt.xlim(-1.5, 1.5)
# plt.ylim(-1.5, 1.5)
# plt.show()





print('***************************')








print('***************************')
