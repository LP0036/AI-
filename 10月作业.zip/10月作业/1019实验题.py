# %% md
# Project1: 对文件diabetes.csv中的数据进行处理，将文件夹pima - diabetes放在E：盘的input文件夹下
# %%
from pandas import *
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
% matplotlib
notebook
from scipy.stats import mode

import os

print(os.listdir("E:/input"))
# %%
################################读入diabetes.csv文件到diabetes###################################
diabetes = pd.read_csv('E:/input/pima-diabetes/diabetes.csv')
################################读入diabetes.csv文件到diabetes###################################
# %%
################################显示diabetes的前5行###################################
diabetes.head(5)
################################显示diabetes的前5行###################################
# %% md
Check
for Summary Statistics
# %%
################################显示diabetes的详细信息，包括样本数、均值、方差等等##################################
diabetes.describe()
################################显示diabetes的详细信息，包括样本数、均值、方差等等##################################
# %%
################################显示diabetes中Outcome列中每种值出现的次数##################################
diabetes["Outcome"].value_counts()
################################显示diabetes中Outcome列中每种值出现的次数##################################
# %% md
### Check missing values
# %%
diabetes.head()
# %%
################################显示diabetes中所有列的标题名##################################
diabetes.columns
################################显示diabetes中所有列的标题名##################################
# %%
################################显示diabetes中所有列的值里面为0的个数##################################
print((diabetes[['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin',
                 'BMI', 'DiabetesPedigreeFunction', 'Age']] == 0).sum())
################################显示diabetes中所有列的值里面为0的个数##################################
# %%
################################将diabetes中所有列的值中为0的值替换为NaN##################################
diabetes.loc[:, ['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin',
                 'BMI']] = diabetes[['Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness', 'Insulin',
                                     'BMI']].replace(0, np.NaN)

################################将diabetes中所有列的值中为0的值替换为NaN##################################
diabetes.head()
# %%
################################统计diabetes中所有列的值中为null的个数##################################
diabetes.isnull().sum()
################################统计diabetes中所有列的值中为null的个数##################################
# %% md
## Dealing with missing values
# %% md
## A. Drop rows having NaN
# %%
print("Size before dropping NaN rows", diabetes.shape, "\n")

################################将diabetes中包含NaN的行删掉##################################
nan_dropped = diabetes.dropna()

################################将diabetes中包含NaN的行删掉##################################
print(nan_dropped.isnull().sum())
print("\nSize after dropping NaN rows", nan_dropped.shape)
# %% md
### **Project2、数据分析的一系列问题**
# %%
vector = np.random.chisquare(1, 500)
print(vector)
################################打印vector的均值##################################
print("Mean", np.mean(vector))
################################打印vector的均值##################################

print("SD", np.std(vector))
print("Range", max(vector) - min(vector))
# %% md
### Reshape
# %%
vector.shape
# %%
################################将一维向量vector转成大小为500*1的二维向量并赋值给row_vector##################################
row_vector = vector.reshape(-1, 1)
################################将一维向量vector转成大小为500*1的二维向量并赋值给row_vector##################################
row_vector.shape
print(row_vector)
# %%
col_vector = vector.reshape(1, -1)
col_vector.shape
# %%
################################将一维向量vector转成大小为10*50的二维向量并赋值给maxtrix##################################
matrix = vector.reshape(10, 50)
################################将一维向量vector转成大小为10*50的二维向量并赋值给maxtrix##################################
matrix.shape
print(matrix)
# %% md
### Pivot Table
# %%
# Determine pivot table
df = pd.DataFrame({"A": ["foo", "foo", "foo", "foo", "foo",
                         "bar", "bar", "bar", "bar"],
                   "B": ["one", "one", "one", "two", "two",
                         "one", "one", "two", "two"],
                   "C": ["small", "large", "large", "small",
                         "small", "large", "small", "small",
                         "large"],
                   "D": [1, 2, 2, 3, 3, 4, 5, 6, 7],
                   "E": [2, 4, 5, 5, 6, 6, 8, 9, 9]})
# %%
df.head(9)
# %%
###################################想办法生成以下表格，行为A、B，列为C###################################
table = pivot_table(df, values='D', index=['A', 'B'],
                    columns=['C'], aggfunc=np.sum)

###################################想办法生成以下表格，行为A、B，列为C###################################
table

# %% md
### Merging dataframes
# %%
df1 = pd.DataFrame({'A': ['A0', 'A1', 'A2', 'A3'],
                    'B': ['B0', 'B1', 'B2', 'B3'],
                    'C': ['C0', 'C1', 'C2', 'C3'],
                    'D': ['D0', 'D1', 'D2', 'D3']},
                   index=[0, 1, 2, 3])

df2 = pd.DataFrame({'A': ['A4', 'A5', 'A6', 'A7'],
                    'B': ['B4', 'B5', 'B6', 'B7'],
                    'C': ['C4', 'C5', 'C6', 'C7'],
                    'D': ['D4', 'D5', 'D6', 'D7']},
                   index=[4, 5, 6, 7])

df3 = pd.DataFrame({'A': ['A8', 'A9', 'A10', 'A11'],
                    'B': ['B8', 'B9', 'B10', 'B11'],
                    'C': ['C8', 'C9', 'C10', 'C11'],
                    'D': ['D8', 'D9', 'D10', 'D11']},
                   index=[8, 9, 10, 11])

###################################将df1,df2,df3按行拼接到一起，并赋给result###################################
frames = [df1, df2, df3]

result = pd.concat(frames)

###################################将df1,df2,df3按行拼接到一起，并赋给result####################################

print(result)
# %%
