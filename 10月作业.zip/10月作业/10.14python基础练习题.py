#——————————第四题
# my_string = 'this is my string'
# print(len(my_string))       #第一种方法
# a = 0
#
# # K='this is my string'       #第二种方法
# for i in my_string[0:]:
#     a = a + 1
# else:
#     print(a)

#——————————第五题
#——————使用while计算1到100的总和————————
# def sum():
#     sum=0
#     x=1
#     while x < 101:
#         sum = sum + x
#         x+=1
#     return sum
# print(sum())
#——————使用for计算1到100的总和————————
# def sum():
#     sum = 0
#     for n in range(1,101):
#         sum =sum + n
#     return sum
# print(sum())

# a = 0
# for i in range(100):
#     a += i
# else:
#     print(a)

#——————————第六题
# n = eval(input("请输入年份（纯数字）："))
# if (n % 4 == 0) or ((n % 400 == 0) and (n % 100 != 0)):
#     print('所输入的年份为闰年。')
# else:
#     print('所输入的年份不是闰年。')

#——————————第七题
# i = 0
# a = "*"
# b = '****'
# while i < 9:
#     print(a)
#     a = a + "*"
#     i += 1
#     while 4 < i < 9:
#         print(b)
#         print(b[0:-2])
#
#         i += 1

#——————————第八题
# a_1 = input('第一个数：')
# a_2 = input('第二个数：')
# if a_1 > a_2:
#     print('''
#             小的数：{}
#             大的数：{}
#             '''.format(a_2, a_1))
# else:
#     print('''
#             小的数：{}
#             大的数：{}
#             '''.format(a_1, a_2))

#——————————第九题
# A, B, C, D = 1, 2, 3, 4
# i = 0
# for x in range(1, 5):
#     for y in range(1, 5):
#         for z in range(1, 5):
#                 if (x != y) and (y != z) and (z != x):
#                     i += 1
#                     if i % 4:
#                         print("%d%d%d" % (x, y, z), end=" | ")
#                     else:
#                         print("%d%d%d" % (x, y, z))

#—————————第十题
# 一个整数，它加上100后是一个完全平方数，再加上168又是一个完全平方数，请问该数是多少？
# 答案为： 21、261、1581
#方法一
# for x in range(1, 100000):
#     for y in range(1, 100000):
#         for z in range(1, 100000):
#             if (x + 100) == y * y and (x + 268) == z * z:
#                 print(x)

#方法二
# import math
# for z in range(10000):
#     x = int(math.sqrt(100 + z))
#     y = int(math.sqrt(268 + z))
#     if (x * x == (100 + z))and (y * y == (z + 268)):
#         print(z)

#——————————第十一题
# X = []
# for x in range(0, 201, 17):
#     X.append(x)
# print(max(X))

#——————————第十二题
# qq = eval(input('请输入一个正整数：'))
# i = 2
# while qq != 1:
#     if qq % i == 0:
#         print(i)
#         qq //= i
#     else:
#         i += 1

#——————————第十三题
# i = 0
# e = 100
# E = []
# sum = 0
# while i < 10:
#     e -= (e / 2)
#     i += 1
# #    print(e)
#     E.append(e)
# for aa in E:
#     sum = sum + aa
# print('第十次掉落时，共经过{:.5}米'.format(sum))
# print('第十次反弹：{:}'.format(e))

#——————————第十四题
# a=[]
# for i in range(100,201):
#     count=0
#     for x in range(2,i-1):
#         if i % x ==0:
#             count +=1
#     if count==0:
#         a.append(i)
# print(a)

#——————————第十五题
# d = {'a': 1, 'b': 2, 'c': 3}
# print("key:'a'  value:{}".format(d['a']))
# print("key:'b'  value:{}".format(d['b']))
# print("key:'c'  value:{}".format(d['c']))

#方法二
# d=('a':1,'b':2,'c':3)
# for key in d:
#     print(key,d[key])

