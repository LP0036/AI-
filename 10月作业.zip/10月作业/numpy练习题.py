
import numpy as np

# 第一题
'''创建一个长度为10的一维全为 0 的 ndarray 对象，然后让第 5 个元素等于 1 '''
# 方式1
# a = np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
# a[4] = 1
# print(a)

# 以下方式会报错。但，当是取[10， 10]时，则可运行，只是结果不符合题意
# a1 = np.zeros([1, 10], dtype=int)
# a1[4] = 1
# print(a1)



# 方式2
# a1 = np.zeros(10, dtype=int)
# a1[4] = 1
# print(a1)

# 方式3
# a1 = np.zeros([1, 10], dtype=int)
# a1[0, 4] = 1
# print(a1)


# 第二题
'''创建一个5 * 3 随机矩阵和一个3 * 2 随机矩阵，求矩阵积'''
# b = np.empty([5, 3], dtype=int)
# b1 = np.empty([3, 2], dtype=int)
# print(b)
# print('*********')
# print(b1)
#
# print('*****相乘****')
# print(np.dot(b, b1))




# 第三题
'''实现冒泡排序法'''
# 方式1
# def nn(arr):
#     n = len(arr)
#
#     for i in range(n):
#         for j in range(0, n - i - 1):
#             if arr[j] > arr[j + 1]:
#                 arr[j], arr[j + 1] = arr[j + 1], arr[j]
# arr1 = eval(input('请输入任意几组纯数字(两数之间用英文状态下的逗号隔开)：'))
# arr = list(arr1)
# nn(arr)
# print('排序后的数组：')
# for i in range(len(arr)):
#     print('%d'%arr[i])
#

# 方式2
# nnn = list(eval(input('请输入任意几组纯数字(两数之间用英文状态下的逗号隔开)：')))
# print('原数组', nnn)
# nnn.sort()
# print('\n', nnn)



# 第四题
'''找到数组 [1， 2， 0， 0， 4， 0] 中 0 元素的位置索引'''

# c = np.array([1, 2,  0, 0, 4, 0])
# print('创建好的数组\n', c)
# i1 = 0
# for i in c:
#     i1 += 1
#     if i == 0:
#         print(i1 - 1)



# 第五题
'''创建一个10 x 10 的随机数组并找到它的最大和最小值'''
# arr = np.empty([10, 10], dtype=int)
#
# print('原数组\n', arr)
# print('****************************************************************************')
# arr.sort()
# print('排序后的数组\n', arr)
#
# print('****************************************************************************')
#
# print('最大值：', np.max(arr))
# print('最小值：', np.min(arr))


# 第六题
'''求解方程
        (3 * x1) + (3.2 * x2) = 118.4
        (3.5 * x1) + (3.6 * x2) = 135.2
'''
# a = [[3, 3.2], [3.5, 3.6]]
# b = [[118.4], [135.2]]
# c = np.array(a)
# print("矩阵1：\n", c)
# print('****************************************************************************')
#
# d = np.array(b)
# print("矩阵2\n", d)
# print('****************************************************************************')

# e = np.linalg.inv(c)
# print("矩阵1的逆矩阵\n", e)
# print('****************************************************************************')
#
# f = np.dot(e, d)
# print('最后的解：\n', f)
# print('x1', int(f[0]))
# print('x2', int(f[1]))
