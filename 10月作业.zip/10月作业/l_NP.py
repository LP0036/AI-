import numpy as np

# ******************************
# import numpy
# print(np.eye(4))

# from numpy import *
# print(eye(4))
# ******************************


# a = np.array([[1, 2], [3, 4]])
# print(a)
# -------------------------------


# a = np.array([[1, 2, 3], [4, 5, 6]])
# print(a)
# -------------------------------


# x = np.empty([3, 2], dtype = int)
# print(x)
# -------------------------------


# x1 = np.zeros([2, 2], dtype=int)
# print(x1)
# print('*******')
# x = np.ones([2, 2], dtype=int)
# print(x)
# print('******')
# x2 = np.ones(5)
# print(x2)
# -------------------------------


# x = [1, 2, 3]
# a = np.asarray(x)
# print(a)
#
# print('******')
#
# #元组变列表
# x = (1, 2, 3)
# a1 = np.asarray(x)
# print(a1)
# -------------------------------


# x = np.arange(10, 20, 2)            #  与range功能一样，都是生成一个数的迭代，只是开头多了个a
# print(x)
# -------------------------------

# a = np.arange(10)
# b = a[2: 7: 2]          #  索引2-7之间，步长为2
# print(b)
# -------------------------------

# a = np.array([[1, 2, 3], (3, 4), (4, 5, 6), (7, 8, 9, 10)])
# print(a)
# print('从数组索引 a[1:] 处开始切割')
# print(a[1:])            #  从列表中的第二个元素（也就是[3，4, 5]）开始，一直到最后一个元素
# print('***********************')
# # -------------------------------
#
# a1 = np.array([[1, 2, 3], [3, 4], [4, 5, 6], [7, 8, 9, 10]])
# print(a1)
# print('从数组索引 a1[1:] 处开始切割')
# print(a1[1:])            # 从列表中的第二个元素（也就是[3，4, 5]）开始，一直到最后一个元素
# # -------------------------------

# 当运算中的2个数组的形状不同时，numpy将自动触发广播机制。
# a = np.array([[0, 0, 0],
#               [10, 10, 10],
#               [20, 20, 20],
#               [30, 30, 30]])
# b = np.array([1, 2, 3])
# print(b + a)    # 但两个数组中的列表的元素个数必须相同，否则报错
# -------------------------------


# a = np.arange(8).reshape(2, 4)      # 将0-7变为两行四列的数组
# print('原数组：')
# print(a)
# print('\n')
# print(a.flatten())
# print('\n')
# print('以F风格顺序展开的数组：')
# print(a.flatten(order='F'))     # order：'C'-按行，  'F'-按列，  'A'-原顺序，  'K'-元素在内存中的出现顺序
# -------------------------------

# a = np.arange(12).reshape(3, 4)
# print('原数组：')
# print(a)
# print('\n')
# print('对换数组：')
# print(np.transpose(a))
# -------------------------------

# a = np.array([[1, 2], [3, 4], [5, 6]])
# print(a)
# print('\n')
#
# b = np.array([[7, 8], [9, 10], [11, 12]])
# print(b)
# print('\n')
#
# print('沿轴 0 连接两个数组：')   # 0 时，按行，为纵向连接两数组
# print(np.concatenate((a, b)))
# print('\n')
#
# print('沿轴 1 连接两个数组：')   # 1 时，按列，为横向连接两数组
# print(np.concatenate((a, b), axis=1))

# -------------------------------

# a = np.array([1.0, 5.55, 123, 0.567, 25.54354])
# print(a)
# print('\n')
# print('舍入后：')
# print(np.around(a))
# print(np.around(a, decimals=1))     # decimals：舍入的小数位数。默认值为0.如果为负，整数将四舍五入到小数点左侧的位置
# print(np.around(a, decimals=-1))

# -------------------------------
# a = np.arange(9, dtype=np.float_).reshape(3, 3)     #三行三列
# b = np.array([10, 10, 10])
# print(a)
# print('********')
# print(b)
# print('*******')
# print('\n')
#
# print(np.add(a, b))
# print('\n')
#
# print(np.subtract(b, a))
# print('\n')
#
# print(np.multiply(a, b))
# print('\n')
#
# print(np.divide(a, b))

# -------------------------------

# a = np.array([30, 65, 70], [])









