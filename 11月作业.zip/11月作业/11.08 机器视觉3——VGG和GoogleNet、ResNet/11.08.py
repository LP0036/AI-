# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# 实验一
# 加载预定义VGG16网络参数，并在Kaggle猫/狗数据集上进行微调和测试# %% [markdown]
# ## 1.加载keras模块

# %%
from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D,ZeroPadding2D
from keras.layers import Activation, Dropout, Flatten, Dense, Input
from keras.utils import to_categorical
from keras.preprocessing.image import img_to_array
from keras.applications.vgg16 import preprocess_input, VGG16
from keras import backend as K
import numpy as np

# %% [markdown]
# ### 加载预训练权值
# 
# 
# %% [markdown]
# ### 定义新加入的layers

# %%
img_width, img_height = 150, 150
if K.image_data_format() == 'channels_first':
    input_shape = (3, img_width, img_height)
else:
    input_shape = (img_width, img_height, 3)
    
# 定义网络输入层shape
input_tensor = Input(shape=input_shape)
#声明VGG网络，并指定加载imagenet预训练模型
model = VGG16(weights='imagenet', include_top=False,input_tensor=input_tensor )
#向VGG网络追加一些全连接层和输出层
top_model = Sequential()
top_model.add(Flatten(input_shape=model.output_shape[1:]))
top_model.add(Dense(256, activation='relu'))
top_model.add(Dropout(0.5))

#指定输出层为2个神经元做2分类，激活函数选用softmax
top_model.add(Dense(2, activation='softmax'))

#把上述网络每一层layer拷贝至一个新的网络，形成一个整体网络
new_model = Sequential()
for l in model.layers:
    new_model.add(l)
new_model.add(top_model)

# %% [markdown]
# ### 设置不需微调的layers的trainable属性
# 并调用compile函数重新编译网络

# %%
from keras.optimizers import SGD
#在新的整体网络上设置对所有原VGG层均不参与微调
for layer in new_model.layers[:4]:
    layer.trainable = False
#compile the model with a SGD/momentum optimizer
# and a very slow learning rate.
#注意此处应选用何种loss function

# %% [markdown]
# ### 定义ImageDataGenerator
# 

# %%
train_data_dir = r'G:\BaiduNetdiskDownload\百度云文件下载\python培训课课件等\11.06 机器视觉1\作业\dogs-vs-cats\train'
validation_data_dir = r'G:\BaiduNetdiskDownload\百度云文件下载\python培训课课件等\11.06 机器视觉1\作业\dogs-vs-cats\validation'
nb_train_samples = 10835
nb_validation_samples = 4000
epochs = 1
batch_size = 20


# this is the augmentation configuration we will use for training
train_datagen = ImageDataGenerator(
    rescale=1. / 255,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True)

# this is the augmentation configuration we will use for testing:
# only rescaling
test_datagen = ImageDataGenerator(rescale=1. / 255)
#此处调用flow_from_directory函数生成train_generator和validation_generator,注意设置class_mode
train_generator = train_datagen.flow_from_directory(
    train_data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='categorical')

validation_generator = test_datagen.flow_from_directory(
    validation_data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='categorical')

# %% [markdown]
# ### 训练模型
# 
# 

# %%
new_model.fit_generator(
    train_generator,
    steps_per_epoch=nb_train_samples // batch_size,
    epochs=epochs,
    validation_data=validation_generator,
    validation_steps=nb_validation_samples // batch_size)

# %% [markdown]
# ### 使用训练后模型预测图像
# 
# 
# 
# 

# %%
from cv2 import cv2 as cv 
img = cv.resize(cv.imread(r'G:\BaiduNetdiskDownload\百度云文件下载\python培训课课件等\11.06 机器视觉1\作业\dogs-vs-cats\test\1.jpg'), (img_width, img_height)).astype(np.float32)
# img[:,:,0] -= 103.939
# img[:,:,1] -= 116.779
# img[:,:,2] -= 123.68
#img = img.transpose((2,0,1))
x = img_to_array(img)

x = np.expand_dims(x, axis=0)

#x = preprocess_input(x)

score = new_model.predict(x)


print(score)

# %% [markdown]
# ###此处尝试只锁定VGG头四层

# %%
#在新的整体网络上设置原VGG前四层不参与微调


#编译网络后进行训练


# %%
#使用训练后模型预测图像

