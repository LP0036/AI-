# setupNLTK.py 
#%%
import nltk
if __name__ == '__main__':
    nltk.download('movie_reviews')

# %%
