package atm.DB;
import java.sql.*;

import javax.swing.JOptionPane;

public class DataBean {
	private Connection conn = null;
	private Statement stmt;
	private ResultSet rs;

	// �������ݿ�����
public void connection() {
	try {
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/account", "root", "123456");
		System.out.println("���ӳɹ���");
	} catch (SQLException ex) {
		System.out.println(ex.getMessage() + "·������");
	} catch (ClassNotFoundException ex) {
		System.out.println(ex.getMessage() + "��������");
	}
}

	// �ر����ݿ�����
public void close() {
	try {
		if (rs != null) {
			rs.close();
		}
		if (stmt != null) {
			stmt.close();
		}
		if (conn != null) {
			conn.close();
		}
	} catch (SQLException ex) {
		ex.printStackTrace();
	}
	System.out.println("�رճɹ���");
}

	// ��ѯ�˻����
public double getBalance(String id) {
	try {
		double balance = -1;
		String sql = "select * from account where id='" + id + "'";
		connection();
		stmt = conn.createStatement();
		rs = stmt.executeQuery(sql);
		while(rs.next()){
			balance = rs.getDouble("balance");
		}
		close();	
		return balance;
	} catch (Exception ex) {
		close();
		ex.printStackTrace();
		return -1;
	}
}

	// ��ѯ�˻�����
	public String getName(String id){
		try{
			String name = "";
			String sql = "select * from account where id='" + id + "'";
			connection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()){
				name = rs.getString(2);
			}
			close();
			return name;
		}catch(Exception ex){
			close();
			ex.printStackTrace();
			return "";
		}
	}
	
	// ��ѯ�˻�����֤
		public String getidcard(String id){
			try{
				String idcard = "";
				String sql = "select * from account where id='" + id + "'";
				connection();
				stmt = conn.createStatement();
				rs = stmt.executeQuery(sql);
				while(rs.next()){
					//idcard = rs.getString(2);
					idcard = rs.getString("idcard");
				}
				close();
				return idcard;
			}catch(Exception ex){
				close();
				ex.printStackTrace();
				return "";
			}
		}
	
	//��ѯ�û�����
	public String getPassword(String id){
		try{
			String password = "";
			String sql = "select * from account where id='" + id + "'";
			connection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()){
				password = rs.getString(3);
			}
			close();
			return password;
		}catch(Exception ex){
			close();
			ex.printStackTrace();
			return "";
		}
	}

	// ��֤�û���¼
	public boolean loginValid(String id, String password) {
		try {
			String sql = "select * from account where id='" + id + "'"
					+ " and password='" + password + "'";
			connection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (!rs.next()) {
				close();
				return false;
			} else {
				close();
				return true;
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			close();
			return false;
		}
	}

	// �޸�����
	public boolean ModiPassword(String id, String newPassword) {
		try {
			String sql = "update account set password='" + newPassword + "'"
					+ " where id='" + id + "'";
			connection();
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			close();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			close();
			return false;
		}
	}

	// ȡǮ
	public boolean draw_deposit(String id, double balance) {
		try {
			String sql = "update account set balance='"+balance+"' where id='" + id + "'";
			connection();
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			close();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();//�������д�ӡ�쳣��Ϣ�ڳ��г�����λ�ü�ԭ��
			close();
			return false;
		}
	}
	
	//ת��
	public boolean TransmitMoney(String srcID,String targetID,double Money){
		try {
			double srcMoney = getBalance(srcID);
			double destMoney = getBalance(targetID);
			if (srcMoney == -1 || destMoney == -1){
				JOptionPane.showMessageDialog(null, "��ȷ���û���Ϣ����!");
				return false;
			}
			
			if (srcMoney < Money)return false;
			srcMoney -= Money;
			destMoney += Money;
			String sql = "update account set balance='"+srcMoney+"' where id='" + srcID + "'";
			connection();
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			stmt = conn.createStatement();
			stmt.executeUpdate("update account set balance='"+destMoney+"' where id='" + targetID + "'");
			close();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			close();
			return false;
		}
	}
}
