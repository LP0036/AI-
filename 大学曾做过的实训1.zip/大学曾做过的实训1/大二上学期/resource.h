//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MystudentDB.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_MYSTUDENTDB_FORM            101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_MYSTUDTYPE                  129
#define IDC_SNO                         1000
#define IDC_SNAME                       1001
#define IDC_SEX                         1003
#define IDC_DEPART                      1004
#define IDC_SNO_QUERY                   1005
#define IDC_BUTTON_QUERY                1006
#define IDC_EDIT1                       1007
#define IDC_EDIT2                       1008
#define IDC_EDIT3                       1009
#define IDC_EDIT4                       1010
#define IDC_BUTTON1                     1011
#define IDC_BUTTON2                     1012
#define IDC_BUTTON3                     1013
#define IDC_BUTTON4                     1014
#define IDC_EDIT5                       1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
