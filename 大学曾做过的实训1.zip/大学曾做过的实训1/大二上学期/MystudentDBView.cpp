// MystudentDBView.cpp : implementation of the CMystudentDBView class
//

#include "stdafx.h"
#include "MystudentDB.h"

#include "MystudentDBSet.h"
#include "MystudentDBDoc.h"
#include "MystudentDBView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMystudentDBView

IMPLEMENT_DYNCREATE(CMystudentDBView, CRecordView)

BEGIN_MESSAGE_MAP(CMystudentDBView, CRecordView)
	//{{AFX_MSG_MAP(CMystudentDBView)
	ON_BN_CLICKED(IDC_BUTTON_QUERY, OnButtonQuery)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_EN_CHANGE(IDC_SNO, OnChangeSno)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CRecordView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMystudentDBView construction/destruction

CMystudentDBView::CMystudentDBView()
	: CRecordView(CMystudentDBView::IDD)
{
	//{{AFX_DATA_INIT(CMystudentDBView)
	m_pSet = NULL;
	m_strQuery = _T("");
	m_addsno = _T("");
	m_addsname = _T("");
	m_addssex = _T("");
	m_adddepart = _T("");
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CMystudentDBView::~CMystudentDBView()
{
}

void CMystudentDBView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMystudentDBView)
	DDX_Text(pDX, IDC_SNO_QUERY, m_strQuery);
	DDX_Text(pDX, IDC_EDIT1, m_addsno);
	DDX_Text(pDX, IDC_EDIT2, m_addsname);
	DDX_FieldText(pDX, IDC_DEPART, m_pSet->m_depart, m_pSet);
	DDX_FieldText(pDX, IDC_SEX, m_pSet->m_ssex, m_pSet);
	DDX_FieldText(pDX, IDC_SNAME, m_pSet->m_sname, m_pSet);
	DDX_FieldText(pDX, IDC_SNO, m_pSet->m_sno, m_pSet);
	DDX_Text(pDX, IDC_EDIT3, m_addssex);
	DDX_Text(pDX, IDC_EDIT4, m_adddepart);
	//}}AFX_DATA_MAP
}

BOOL CMystudentDBView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRecordView::PreCreateWindow(cs);
}

void CMystudentDBView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_mystudentDBSet;
	CRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CMystudentDBView printing

BOOL CMystudentDBView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMystudentDBView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMystudentDBView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMystudentDBView diagnostics

#ifdef _DEBUG
void CMystudentDBView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CMystudentDBView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CMystudentDBDoc* CMystudentDBView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMystudentDBDoc)));
	return (CMystudentDBDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMystudentDBView database support
CRecordset* CMystudentDBView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CMystudentDBView message handlers

void CMystudentDBView::OnButtonQuery() 
{
UpdateData();
	m_strQuery.TrimLeft();
	if(m_strQuery.IsEmpty())
	{
		MessageBox("Ҫ��ѯ�ĺ��벻��Ϊ��!");
		return;}
	if(m_pSet->IsOpen())
		m_pSet->Close();
	m_pSet->m_strFilter.Format("sno='%s'",m_strQuery);
	m_pSet->m_strSort="depart";
	m_pSet->Open();
	if(!m_pSet->IsEOF())
		UpdateData(FALSE);
	else
		MessageBox("û�в鵽��Ҫ�ҵĵ绰��¼!");
}
	// TODO: Add your control notification handler code here
	


void CMystudentDBView::OnButton1() 
{
UpdateData();
	m_pSet->AddNew();
	m_pSet->m_sno=m_addsno;
	m_pSet->m_sname=m_addsname;
    m_pSet->m_ssex=m_addssex;
	m_pSet->m_depart=m_adddepart;
	m_pSet->Update();
	m_pSet->MoveLast();
	m_pSet->Requery();
	MessageBox("���Ӽ�¼�ɹ�");
	m_addsno=m_addsname=m_addssex=m_adddepart="";
	UpdateData(false);
	// TODO: Add your control notification handler code here
	
}

void CMystudentDBView::OnButton3() 
{
	m_pSet->Edit();
	UpdateData();
	m_pSet->Update();
	m_pSet->Requery();
	MessageBox("�޸ĳɹ�!");
	UpdateData(false);

	// TODO: Add your control notification handler code here
	
}

void CMystudentDBView::OnButton2() 
{
m_pSet->Delete();
     m_pSet->Requery();
	MessageBox("ɾ���ɹ�");
	UpdateData(false);
	m_pSet->MoveNext();
	if(m_pSet->IsEOF())
	{   m_pSet->MoveLast();
	    UpdateData(false); }

	// TODO: Add your control notification handler code here
	
}

void CMystudentDBView::OnButton4() 
{

if(m_pSet->IsOpen())
		m_pSet->Close();
	m_pSet->m_strFilter.Empty();
	m_pSet->Open();
	m_pSet->Requery();
	UpdateData(false);
	// TODO: Add your control notification handler code here
	
}

void CMystudentDBView::OnChangeSno() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CRecordView::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
}
