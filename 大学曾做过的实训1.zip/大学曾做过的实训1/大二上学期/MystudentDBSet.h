// MystudentDBSet.h : interface of the CMystudentDBSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYSTUDENTDBSET_H__B9F4DC0D_2CB9_4073_AD9F_FB8D7ECB4EAA__INCLUDED_)
#define AFX_MYSTUDENTDBSET_H__B9F4DC0D_2CB9_4073_AD9F_FB8D7ECB4EAA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMystudentDBSet : public CRecordset
{
public:
	CMystudentDBSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CMystudentDBSet)

// Field/Param Data
	//{{AFX_FIELD(CMystudentDBSet, CRecordset)
	long	m_ID;
	CString	m_sno;
	CString	m_sname;
	CString	m_ssex;
	CString	m_depart;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMystudentDBSet)
	public:
	virtual CString GetDefaultConnect();	// Default connection string
	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);	// RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSTUDENTDBSET_H__B9F4DC0D_2CB9_4073_AD9F_FB8D7ECB4EAA__INCLUDED_)

