// MystudentDBView.h : interface of the CMystudentDBView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYSTUDENTDBVIEW_H__37C8533D_FD85_451D_B141_4A944E8F088C__INCLUDED_)
#define AFX_MYSTUDENTDBVIEW_H__37C8533D_FD85_451D_B141_4A944E8F088C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMystudentDBSet;

class CMystudentDBView : public CRecordView
{
protected: // create from serialization only
	CMystudentDBView();
	DECLARE_DYNCREATE(CMystudentDBView)

public:
	//{{AFX_DATA(CMystudentDBView)
	enum { IDD = IDD_MYSTUDENTDB_FORM };
	CMystudentDBSet* m_pSet;
	CString	m_strQuery;
	CString	m_addsno;
	CString	m_addsname;
	CString	m_addssex;
	CString	m_adddepart;
	//}}AFX_DATA

// Attributes
public:
	CMystudentDBDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMystudentDBView)
	public:
	virtual CRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMystudentDBView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMystudentDBView)
	afx_msg void OnButtonQuery();
	afx_msg void OnButton1();
	afx_msg void OnButton3();
	afx_msg void OnButton2();
	afx_msg void OnButton4();
	afx_msg void OnChangeSno();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MystudentDBView.cpp
inline CMystudentDBDoc* CMystudentDBView::GetDocument()
   { return (CMystudentDBDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSTUDENTDBVIEW_H__37C8533D_FD85_451D_B141_4A944E8F088C__INCLUDED_)
