// MystudentDBDoc.h : interface of the CMystudentDBDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYSTUDENTDBDOC_H__3BAB6279_DE30_4030_8537_78B0CD80C92E__INCLUDED_)
#define AFX_MYSTUDENTDBDOC_H__3BAB6279_DE30_4030_8537_78B0CD80C92E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "MystudentDBSet.h"


class CMystudentDBDoc : public CDocument
{
protected: // create from serialization only
	CMystudentDBDoc();
	DECLARE_DYNCREATE(CMystudentDBDoc)

// Attributes
public:
	CMystudentDBSet m_mystudentDBSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMystudentDBDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMystudentDBDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMystudentDBDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSTUDENTDBDOC_H__3BAB6279_DE30_4030_8537_78B0CD80C92E__INCLUDED_)
