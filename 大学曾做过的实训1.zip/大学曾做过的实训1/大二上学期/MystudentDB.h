// MystudentDB.h : main header file for the MYSTUDENTDB application
//

#if !defined(AFX_MYSTUDENTDB_H__1A53A21E_FBF6_4404_8357_D9A7DA1D8F4C__INCLUDED_)
#define AFX_MYSTUDENTDB_H__1A53A21E_FBF6_4404_8357_D9A7DA1D8F4C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMystudentDBApp:
// See MystudentDB.cpp for the implementation of this class
//

class CMystudentDBApp : public CWinApp
{
public:
	CMystudentDBApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMystudentDBApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CMystudentDBApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSTUDENTDB_H__1A53A21E_FBF6_4404_8357_D9A7DA1D8F4C__INCLUDED_)
