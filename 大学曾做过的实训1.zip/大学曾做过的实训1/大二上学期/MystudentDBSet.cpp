// MystudentDBSet.cpp : implementation of the CMystudentDBSet class
//

#include "stdafx.h"
#include "MystudentDB.h"
#include "MystudentDBSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMystudentDBSet implementation

IMPLEMENT_DYNAMIC(CMystudentDBSet, CRecordset)

CMystudentDBSet::CMystudentDBSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CMystudentDBSet)
	m_ID = 0;
	m_sno = _T("");
	m_sname = _T("");
	m_ssex = _T("");
	m_depart = _T("");
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}

CString CMystudentDBSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=MFC ODBC");
}

CString CMystudentDBSet::GetDefaultSQL()
{
	return _T("[��1]");
}

void CMystudentDBSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CMystudentDBSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Long(pFX, _T("[ID]"), m_ID);
	RFX_Text(pFX, _T("[sno]"), m_sno);
	RFX_Text(pFX, _T("[sname]"), m_sname);
	RFX_Text(pFX, _T("[ssex]"), m_ssex);
	RFX_Text(pFX, _T("[depart]"), m_depart);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CMystudentDBSet diagnostics

#ifdef _DEBUG
void CMystudentDBSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CMystudentDBSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
